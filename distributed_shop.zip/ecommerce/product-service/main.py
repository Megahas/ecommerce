"""
Product Service - Distributed E-Commerce System
Manages the product catalog and inventory.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlite3, os

app = FastAPI(title="Product Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = "/data/products.db"

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            description TEXT,
            price       REAL    NOT NULL,
            stock       INTEGER NOT NULL DEFAULT 0,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    sample_products = [
        ("Wireless Headphones", "Noise-cancelling over-ear headphones with 30hr battery", 79.99, 50),
        ("Mechanical Keyboard",  "TKL layout, Cherry MX switches, RGB backlit",           129.99, 30),
        ("USB-C Hub",            "7-in-1 USB-C hub with HDMI, PD charging, and USB 3.0",   39.99, 100),
        ("Laptop Stand",         "Aluminium adjustable laptop stand for desk use",           49.99, 75),
    ]
    for name, desc, price, stock in sample_products:
        try:
            conn.execute(
                "INSERT INTO products (name, description, price, stock) VALUES (?,?,?,?)",
                (name, desc, price, stock)
            )
        except Exception:
            pass
    conn.commit()
    conn.close()

init_db()

class ProductCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    price: float
    stock: int

class StockUpdate(BaseModel):
    quantity: int

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "product-service"}

@app.post("/products", status_code=201)
def create_product(product: ProductCreate):
    conn = get_db()
    cursor = conn.execute(
        "INSERT INTO products (name, description, price, stock) VALUES (?,?,?,?)",
        (product.name, product.description, product.price, product.stock)
    )
    conn.commit()
    row = conn.execute("SELECT * FROM products WHERE id=?", (cursor.lastrowid,)).fetchone()
    conn.close()
    return dict(row)

@app.get("/products/{product_id}")
def get_product(product_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
    return dict(row)

@app.patch("/products/{product_id}/stock")
def update_stock(product_id: int, update: StockUpdate):
    conn = get_db()
    row = conn.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Product not found")
    new_stock = row["stock"] + update.quantity
    if new_stock < 0:
        conn.close()
        raise HTTPException(status_code=409, detail="Insufficient stock")
    conn.execute("UPDATE products SET stock=? WHERE id=?", (new_stock, product_id))
    conn.commit()
    conn.close()
    return {"product_id": product_id, "new_stock": new_stock}

@app.get("/products")
def list_products():
    conn = get_db()
    rows = conn.execute("SELECT * FROM products").fetchall()
    conn.close()
    return [dict(r) for r in rows]