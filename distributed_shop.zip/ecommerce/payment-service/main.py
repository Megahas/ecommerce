"""
Payment Simulation Service - Distributed E-Commerce System
Returns SUCCESS ~80% of the time and FAILURE ~20%.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import random, uuid, logging

app = FastAPI(
    title="Payment Simulation Service",
    version="1.0.0",
    description="Simulates payment gateway responses"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PaymentRequest(BaseModel):
    user_id: int
    amount: float

class PaymentResponse(BaseModel):
    transaction_id: str
    status: str
    amount: float
    message: str

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "payment-service"}

@app.post("/pay", response_model=PaymentResponse)
def process_payment(payment: PaymentRequest):
    transaction_id = str(uuid.uuid4())
    SUCCESS_RATE = 0.80
    is_success = random.random() < SUCCESS_RATE
    status  = "SUCCESS" if is_success else "FAILED"
    message = (
        f"Payment of ${payment.amount:.2f} authorised for user {payment.user_id}."
        if is_success else
        f"Payment of ${payment.amount:.2f} declined — insufficient funds (simulated)."
    )
    logger.info(f"[{transaction_id}] user={payment.user_id} amount=${payment.amount:.2f} -> {status}")
    return PaymentResponse(
        transaction_id=transaction_id,
        status=status,
        amount=payment.amount,
        message=message
    )