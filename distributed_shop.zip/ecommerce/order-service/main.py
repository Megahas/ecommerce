"""
Order Service - Distributed E-Commerce System
Orchestrates order placement across all services.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlite3, httpx, os, logging

app = FastAPI(title="Order Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DB_PATH = "/data/orders.db"
USER_SERVICE_URL    = os.getenv("USER_SERVICE_URL",    "http://user-service:8000")
PRODUCT_SERVICE_URL = os.getenv("PRODUCT_SERVICE_URL", "http://product-service:8000")
PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://payment-service:8000")

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            product_id      INTEGER NOT NULL,
            quantity        INTEGER NOT NULL,
            total_price     REAL    NOT NULL,
            payment_status  TEXT    NOT NULL,
            order_status    TEXT    NOT NULL,
            created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

def _get(url, service_name):
    try:
        response = httpx.get(url, timeout=5.0)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code,
                            detail=f"{service_name}: {e.response.json().get('detail', 'Error')}")
    except httpx.RequestError:
        raise HTTPException(status_code=503, detail=f"{service_name} is unavailable")

def _post(url, payload, service_name):
    try:
        response = httpx.post(url, json=payload, timeout=5.0)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code,
                            detail=f"{service_name}: {e.response.json().get('detail', 'Error')}")
    except httpx.RequestError:
        raise HTTPException(status_code=503, detail=f"{service_name} is unavailable")

def _patch(url, payload, service_name):
    try:
        response = httpx.patch(url, json=payload, timeout=5.0)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code,
                            detail=f"{service_name}: {e.response.json().get('detail', 'Error')}")
    except httpx.RequestError:
        raise HTTPException(status_code=503, detail=f"{service_name} is unavailable")

class OrderCreate(BaseModel):
    user_id: int
    product_id: int
    quantity: int = 1

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "order-service"}

@app.post("/orders", status_code=201)
def place_order(order: OrderCreate):
    logger.info(f"Placing order: user={order.user_id}, product={order.product_id}, qty={order.quantity}")
    user    = _get(f"{USER_SERVICE_URL}/users/{order.user_id}", "User Service")
    product = _get(f"{PRODUCT_SERVICE_URL}/products/{order.product_id}", "Product Service")
    if product["stock"] < order.quantity:
        raise HTTPException(status_code=409, detail=f"Only {product['stock']} units in stock")
    total_price = round(product["price"] * order.quantity, 2)
    payment_result = _post(f"{PAYMENT_SERVICE_URL}/pay",
                           {"user_id": order.user_id, "amount": total_price}, "Payment Service")
    payment_status = payment_result["status"]
    order_status   = "CONFIRMED" if payment_status == "SUCCESS" else "PAYMENT_FAILED"
    if payment_status == "SUCCESS":
        _patch(f"{PRODUCT_SERVICE_URL}/products/{order.product_id}/stock",
               {"quantity": -order.quantity}, "Product Service")
    conn = get_db()
    cursor = conn.execute(
        "INSERT INTO orders (user_id, product_id, quantity, total_price, payment_status, order_status) VALUES (?,?,?,?,?,?)",
        (order.user_id, order.product_id, order.quantity, total_price, payment_status, order_status)
    )
    conn.commit()
    row = conn.execute("SELECT * FROM orders WHERE id=?", (cursor.lastrowid,)).fetchone()
    conn.close()
    return dict(row)

@app.get("/orders/{order_id}")
def get_order(order_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail=f"Order {order_id} not found")
    return dict(row)

@app.get("/orders")
def list_orders(user_id: Optional[int] = None):
    conn = get_db()
    if user_id:
        rows = conn.execute("SELECT * FROM orders WHERE user_id=?", (user_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM orders").fetchall()
    conn.close()
    return [dict(r) for r in rows]