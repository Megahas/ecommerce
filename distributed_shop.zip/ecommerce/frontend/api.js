/* api.js — all backend calls */
const BASE = {
  USER:    'https://solid-acorn-4j7p56gqprx5cx4v-8001.app.github.dev',
  PRODUCT: 'https://solid-acorn-4j7p56gqprx5cx4v-8002.app.github.dev',
  ORDER:   'https://solid-acorn-4j7p56gqprx5cx4v-8003.app.github.dev',
  PAYMENT: 'https://solid-acorn-4j7p56gqprx5cx4v-8004.app.github.dev',
};

async function apiFetch(base, path, opts = {}) {
  const url = `${base}${path}`;
  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json', ...opts.headers },
      ...opts,
    });
    if (!res.ok) {
      let msg = `HTTP ${res.status}`;
      try { const j = await res.json(); msg = j.detail || msg; } catch {}
      throw new Error(msg);
    }
    return res.json();
  } catch (e) {
    // Normalise all network/fetch failures to one detectable message
    if (e.name === 'TypeError' || e.message === 'Failed to fetch' || e.message.includes('NetworkError')) {
      throw new Error(`Backend not reachable at ${base} — make sure Docker is running`);
    }
    throw e;
  }
}

const UserAPI = {
  list:   ()     => apiFetch(BASE.USER, '/users'),
  get:    (id)   => apiFetch(BASE.USER, `/users/${id}`),
  create: (body) => apiFetch(BASE.USER, '/users', { method: 'POST', body: JSON.stringify(body) }),
};
const ProductAPI = {
  list:   ()     => apiFetch(BASE.PRODUCT, '/products'),
  get:    (id)   => apiFetch(BASE.PRODUCT, `/products/${id}`),
  create: (body) => apiFetch(BASE.PRODUCT, '/products', { method: 'POST', body: JSON.stringify(body) }),
};
const OrderAPI = {
  list:   (uid)  => apiFetch(BASE.ORDER, uid ? `/orders?user_id=${uid}` : '/orders'),
  place:  (body) => apiFetch(BASE.ORDER, '/orders', { method: 'POST', body: JSON.stringify(body) }),
};