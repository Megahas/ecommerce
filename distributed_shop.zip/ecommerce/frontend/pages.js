/* pages.js — all customer-facing pages */

/* ════════════════════ HOME ════════════════════ */
async function renderHome() {
  const el = document.getElementById('page-home');
  el.innerHTML = renderNavbar('home') + `
    <section class="hero">
      <div class="hero-left">
        <div class="hero-eyebrow">New Collection 2026</div>
        <h1 class="hero-title">Premium Tech,<br/>Delivered Fast.</h1>
        <p class="hero-body">The finest audio gear, peripherals, and accessories — curated for professionals and enthusiasts.</p>
        <div class="hero-actions">
          <button class="btn-primary" style="padding:14px 32px;font-size:15px" onclick="goTo('products')">Shop Collection</button>
          <button class="btn-ghost" style="padding:14px 24px;font-size:15px" onclick="goTo('products')">View All Products</button>
        </div>
      </div>
      <div class="hero-right">
        <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=85" alt="Premium Headphones"/>
        <div class="hero-right-overlay"></div>
      </div>
    </section>

    <div style="padding:48px 0 0;background:#fff">
      <div class="container">
        <div class="section-head">
          <div>
            <div class="section-title">Bestsellers</div>
            <div class="section-sub">Our most popular products this season</div>
          </div>
          <button class="btn-ghost btn-sm" onclick="goTo('products')">View All →</button>
        </div>
        <div class="products-grid" id="home-grid">${loading()}</div>
      </div>
    </div>

    <div style="padding:64px 0;background:var(--bg2);margin-top:60px">
      <div class="container">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:32px;text-align:center">
          <div>
            <div style="font-size:32px;margin-bottom:10px">🚚</div>
            <div style="font-weight:600;margin-bottom:6px">Free Shipping</div>
            <div style="font-size:13px;color:var(--text3)">On all orders over $75</div>
          </div>
          <div>
            <div style="font-size:32px;margin-bottom:10px">↩</div>
            <div style="font-weight:600;margin-bottom:6px">Easy Returns</div>
            <div style="font-size:13px;color:var(--text3)">30-day return policy</div>
          </div>
          <div>
            <div style="font-size:32px;margin-bottom:10px">🔒</div>
            <div style="font-weight:600;margin-bottom:6px">Secure Checkout</div>
            <div style="font-size:13px;color:var(--text3)">Multiple payment methods</div>
          </div>
        </div>
      </div>
    </div>
  `;

  try {
    const products = await loadProducts();
    const grid = document.getElementById('home-grid');
    if (!grid) return;
    grid.innerHTML = products.slice(0, 4).map(p => productCard(p)).join('');
  } catch (e) {
    const grid = document.getElementById('home-grid');
    if (grid) grid.innerHTML = `<div class="empty"><p>⚠ Could not load products — make sure the backend is running.<br/><small>${e.message}</small></p></div>`;
  }
}

/* ════════════════════ PRODUCTS ════════════════════ */
let activeCategory = 'All';

async function renderProducts(category) {
  if (category) activeCategory = category;
  const el = document.getElementById('page-products');

  el.innerHTML = renderNavbar('products') + `
    <div class="container section">
      <div class="section-head">
        <div>
          <div class="section-title">Shop All Products</div>
          <div class="section-sub" id="prod-count">Loading products…</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <select id="sort-select" onchange="sortProducts()" style="padding:8px 12px;border:1.5px solid var(--border2);border-radius:var(--r);font-size:13px;background:#fff">
            <option value="default">Sort: Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="name">Name A–Z</option>
          </select>
        </div>
      </div>
      <div class="cat-strip" id="cat-strip">
        <span class="cat-chip active" onclick="filterByCategory('All',this)">All</span>
      </div>
      <div class="products-grid" id="products-grid">${loading()}</div>
    </div>
  `;

  try {
    const products = await loadProducts(true);
    renderProductGrid(products);
  } catch (e) {
    const grid = document.getElementById('products-grid');
    if (grid) grid.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`;
  }
}

let currentProducts = [];

function renderProductGrid(products) {
  currentProducts = products;
  const strip = document.getElementById('cat-strip');
  const grid  = document.getElementById('products-grid');
  const count = document.getElementById('prod-count');
  if (!grid) return;

  // Build category chips
  const cats = ['All', ...new Set(products.map(p => p.category || 'Tech'))];
  if (strip) {
    strip.innerHTML = cats.map(c =>
      `<span class="cat-chip ${activeCategory===c?'active':''}" onclick="filterByCategory('${c}',this)">${c}</span>`
    ).join('');
  }

  const filtered = activeCategory === 'All' ? products : products.filter(p => (p.category||'Tech') === activeCategory);
  if (count) count.textContent = `${filtered.length} product${filtered.length !== 1 ? 's' : ''}`;
  if (!filtered.length) { grid.innerHTML = `<div class="empty"><span class="big">📦</span><p>No products found</p></div>`; return; }
  grid.innerHTML = filtered.map(p => productCard(p)).join('');
}

function filterByCategory(cat, el) {
  activeCategory = cat;
  document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  renderProductGrid(currentProducts);
}

function sortProducts() {
  const val = document.getElementById('sort-select').value;
  let sorted = [...currentProducts];
  if (val === 'price-asc')  sorted.sort((a,b) => a.price - b.price);
  if (val === 'price-desc') sorted.sort((a,b) => b.price - a.price);
  if (val === 'name')       sorted.sort((a,b) => a.name.localeCompare(b.name));
  const grid = document.getElementById('products-grid');
  if (grid) grid.innerHTML = sorted.map(p => productCard(p)).join('');
}

function productCard(p) {
  const inStock = p.stock > 0;
  const badge = p.stock === 0 ? `<span class="pcard-badge badge-out">Out of Stock</span>`
    : p.stock <= 5 ? `<span class="pcard-badge badge-low">Only ${p.stock} left</span>`
    : p.id <= 2 ? `<span class="pcard-badge badge-new">New</span>` : '';

  return `
    <div class="pcard" onclick="goTo('product',${p.id})">
      <div class="pcard-img-wrap">
        <img src="${productImg(p)}" alt="${p.name}" onerror="this.style.display='none'"/>
        ${badge}
      </div>
      <div class="pcard-name">${p.name}</div>
      <div class="pcard-sub">${p.description ? p.description.split('.')[0] : 'Premium quality'}</div>
      <div class="pcard-row">
        <span class="pcard-price">$${p.price.toFixed(2)}</span>
        <button class="pcard-add" ${!inStock?'disabled':''} title="Add to cart"
          onclick="event.stopPropagation();if(${inStock}){quickAdd(${p.id})}" >+</button>
      </div>
    </div>
  `;
}

async function quickAdd(productId) {
  try {
    const p = productsCache.find(x => x.id === productId) || await ProductAPI.get(productId);
    cartAdd(p, 1);
    openCart();
  } catch(e) { showToast(e.message, 'error'); }
}

/* ════════════════════ PRODUCT DETAIL ════════════════════ */
let detailProduct = null;
let detailQty = 1;
let activeThumb = 0;

async function renderProductDetail(id) {
  detailQty = 1; activeThumb = 0;
  const el = document.getElementById('page-product');
  el.innerHTML = renderNavbar('products') + `<div class="container">${loading()}</div>`;

  try {
    const p = await ProductAPI.get(id);
    detailProduct = p;
    const img = productImg(p);
    const inStock = p.stock > 0;
    const stockEl = p.stock === 0
      ? `<span class="detail-stock nostock">✕ Out of stock</span>`
      : p.stock <= 5
      ? `<span class="detail-stock lowstock">⚠ Only ${p.stock} left</span>`
      : `<span class="detail-stock instock">✓ In Stock (${p.stock} available)</span>`;

    el.innerHTML = renderNavbar('products') + `
      <div class="container" style="padding-top:12px;padding-bottom:8px">
        <div style="font-size:13px;color:var(--text3)">
          <span onclick="goTo('home')" style="cursor:pointer">Home</span>
          <span style="margin:0 6px">›</span>
          <span onclick="goTo('products')" style="cursor:pointer">Shop</span>
          <span style="margin:0 6px">›</span>
          <span>${p.name}</span>
        </div>
      </div>
      <div class="detail-wrap">
        <div class="detail-gallery">
          <div class="detail-main-img" id="main-img">
            <img src="${img}" alt="${p.name}" id="main-img-el" onerror="this.style.background='var(--bg2)'"/>
          </div>
          <div class="detail-thumbs">
            <div class="detail-thumb active" onclick="switchThumb(0,'${img}',this)">
              <img src="${img}" alt="${p.name}"/>
            </div>
          </div>
        </div>
        <div class="detail-body">
          <div class="detail-brand">NEXUS STORE</div>
          <h1 class="detail-name">${p.name}</h1>
          <div class="detail-rating">
            <span class="stars">★★★★★</span>
            <span>4.8 (124 reviews)</span>
          </div>
          <div class="detail-price">$${p.price.toFixed(2)}</div>
          <p class="detail-desc">${p.description || 'Premium quality product from NEXUS Store. Designed for professionals who demand the best.'}</p>
          ${stockEl}
          <ul class="detail-features" style="margin-top:16px">
            <li>Free shipping on orders over $75</li>
            <li>30-day hassle-free returns</li>
            <li>1-year manufacturer warranty</li>
            <li>Secure checkout with multiple payment options</li>
          </ul>
          <div class="qty-row">
            <span class="qty-label">Quantity</span>
            <div class="qty-box">
              <button onclick="changeQty(-1)">−</button>
              <span id="qty-val">1</span>
              <button onclick="changeQty(1)">+</button>
            </div>
          </div>
          <div class="detail-actions">
            <button class="btn-primary" style="flex:1;padding:14px" ${!inStock?'disabled':''}
              onclick="addDetailToCart()">
              ${inStock ? '🛒 Add to Cart' : 'Out of Stock'}
            </button>
            <button class="btn-ghost" style="padding:14px 18px" onclick="goTo('products')">← Back</button>
          </div>
          <div class="detail-meta">
            <div class="detail-meta-row"><span>Product ID</span><span>#${p.id}</span></div>
            <div class="detail-meta-row"><span>In Stock</span><span>${p.stock} units</span></div>
            <div class="detail-meta-row"><span>Served by</span><span>Product Service :8002</span></div>
            <div class="detail-meta-row"><span>Database</span><span>products.db (SQLite)</span></div>
          </div>
        </div>
      </div>
    `;
  } catch (e) {
    el.innerHTML = renderNavbar('products') + `<div class="empty"><span class="big">😕</span><p>${e.message}</p></div>`;
  }
}

function switchThumb(idx, src, el) {
  activeThumb = idx;
  document.querySelectorAll('.detail-thumb').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  const mi = document.getElementById('main-img-el');
  if (mi) mi.src = src;
}

function changeQty(delta) {
  if (!detailProduct) return;
  detailQty = Math.max(1, Math.min(detailProduct.stock, detailQty + delta));
  const el = document.getElementById('qty-val');
  if (el) el.textContent = detailQty;
}

function addDetailToCart() {
  if (!detailProduct) return;
  cartAdd(detailProduct, detailQty);
  openCart();
}

/* ════════════════════ CHECKOUT ════════════════════ */
function renderCheckout() {
  const el = document.getElementById('page-checkout');
  if (!currentUser) {
    el.innerHTML = renderNavbar('') + signWall('checkout');
    return;
  }
  if (cart.length === 0) {
    el.innerHTML = renderNavbar('') + `
      <div class="empty" style="padding-top:80px">
        <span class="big">🛒</span>
        <p>Your cart is empty</p>
        <button class="btn-primary" style="margin-top:16px" onclick="goTo('products')">Start Shopping</button>
      </div>`;
    return;
  }

  const subtotal = cartTotal();
  const shipping = subtotal >= 75 ? 0 : 9.99;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const orderItems = cart.map(({ product, qty }) => `
    <div class="ob-item">
      <div class="ob-img"><img src="${productImg(product)}" alt="${product.name}" style="object-fit:cover;width:100%;height:100%"/></div>
      <div class="ob-info">
        <div class="ob-name">${product.name}</div>
        <div class="ob-qty">Qty: ${qty}</div>
      </div>
      <div class="ob-price">$${(product.price * qty).toFixed(2)}</div>
    </div>
  `).join('');

  el.innerHTML = renderNavbar('') + `
    <div class="checkout-wrap">
      <div>
        <div class="co-title">Checkout</div>

        <div class="co-section">
          <div class="co-section-title">Contact Information</div>
          <div class="field-row">
            <div class="field">
              <label>First Name *</label>
              <input id="co-fname" value="${currentUser.name.split(' ')[0]}" placeholder="First name"
                oninput="clearErr(this)" onblur="validateName(this,'First name')"/>
              <span class="field-err" id="err-fname"></span>
            </div>
            <div class="field">
              <label>Last Name</label>
              <input id="co-lname" value="${currentUser.name.split(' ').slice(1).join(' ')}" placeholder="Last name"/>
            </div>
          </div>
          <div class="field">
            <label>Email *</label>
            <input id="co-email" value="${currentUser.email}" type="email" placeholder="you@example.com"
              oninput="clearErr(this)" onblur="validateEmail(this)"/>
            <span class="field-err" id="err-email"></span>
          </div>
          <div class="field">
            <label>Phone *</label>
            <input id="co-phone" placeholder="03XX-XXXXXXX" type="tel" maxlength="15"
              oninput="clearErr(this);formatPhone(this)" onblur="validatePhone(this)"/>
            <span class="field-err" id="err-phone"></span>
          </div>
        </div>

        <div class="co-section">
          <div class="co-section-title">Delivery Address</div>
          <div class="field">
            <label>Street Address *</label>
            <input id="co-addr" placeholder="House/Flat no., Street name, Area"
              oninput="clearErr(this)" onblur="validateRequired(this,'Street address')"/>
            <span class="field-err" id="err-addr"></span>
          </div>
          <div class="field-row">
            <div class="field">
              <label>City *</label>
              <input id="co-city" placeholder="Karachi"
                oninput="clearErr(this)" onblur="validateRequired(this,'City')"/>
              <span class="field-err" id="err-city"></span>
            </div>
            <div class="field">
              <label>Postal Code *</label>
              <input id="co-zip" placeholder="75000" maxlength="10"
                oninput="clearErr(this);this.value=this.value.replace(/\D/g,'')" onblur="validateZip(this)"/>
              <span class="field-err" id="err-zip"></span>
            </div>
          </div>
          <div class="field">
            <label>Country</label>
            <select id="co-country">
              <option>Pakistan</option><option>United States</option>
              <option>United Kingdom</option><option>UAE</option><option>Saudi Arabia</option>
            </select>
          </div>
        </div>

        <div class="co-section">
          <div class="co-section-title">Payment Method</div>
          <div class="payment-methods">
            <label class="pay-option selected" id="pm-card" onclick="selectPayment('card')">
              <input type="radio" name="payment" checked/>
              <div class="pay-icon pay-visa">VISA</div>
              <div class="pay-label">
                <div class="pay-name">Credit / Debit Card</div>
                <div class="pay-desc">Visa, Mastercard, or local bank cards</div>
              </div>
            </label>
            <label class="pay-option" id="pm-easypaisa" onclick="selectPayment('easypaisa')">
              <input type="radio" name="payment"/>
              <div class="pay-icon pay-easypaisa">EP</div>
              <div class="pay-label">
                <div class="pay-name">EasyPaisa</div>
                <div class="pay-desc">Pay via EasyPaisa mobile wallet</div>
              </div>
            </label>
            <label class="pay-option" id="pm-jazzcash" onclick="selectPayment('jazzcash')">
              <input type="radio" name="payment"/>
              <div class="pay-icon pay-jazzcash">JC</div>
              <div class="pay-label">
                <div class="pay-name">JazzCash</div>
                <div class="pay-desc">Pay via JazzCash mobile wallet</div>
              </div>
            </label>
            <label class="pay-option" id="pm-cash" onclick="selectPayment('cash')">
              <input type="radio" name="payment"/>
              <div class="pay-icon pay-cash">💵</div>
              <div class="pay-label">
                <div class="pay-name">Cash on Delivery</div>
                <div class="pay-desc">Pay when your order arrives</div>
              </div>
            </label>
          </div>

          <!-- Only ONE of these shows at a time based on selected payment -->
          <div id="card-fields" class="card-fields">
            <div class="field">
              <label>Card Number *</label>
              <input id="co-card" placeholder="1234 5678 9012 3456" maxlength="19"
                oninput="clearErr(this);formatCard(this)" onblur="validateCardNumber(this)"/>
              <span class="field-err" id="err-card"></span>
            </div>
            <div class="field-row">
              <div class="field">
                <label>Expiry Date *</label>
                <input id="co-expiry" placeholder="MM/YY" maxlength="5"
                  oninput="clearErr(this);formatExpiry(this)" onblur="validateExpiry(this)"/>
                <span class="field-err" id="err-expiry"></span>
              </div>
              <div class="field">
                <label>CVV *</label>
                <input id="co-cvv" placeholder="123" maxlength="3" type="password"
                  oninput="clearErr(this);this.value=this.value.replace(/\D/g,'')" onblur="validateCVV(this)"/>
                <span class="field-err" id="err-cvv"></span>
              </div>
            </div>
            <div class="field">
              <label>Name on Card *</label>
              <input id="co-cardname" placeholder="As printed on card"
                oninput="clearErr(this)" onblur="validateRequired(this,'Name on card')"/>
              <span class="field-err" id="err-cardname"></span>
            </div>
          </div>

          <div id="ep-fields" class="card-fields" style="display:none">
            <div class="field">
              <label>EasyPaisa Mobile Number *</label>
              <input id="co-ep-num" placeholder="03XX-XXXXXXX" type="tel" maxlength="15"
                oninput="clearErr(this);formatPhone(this)" onblur="validatePhone(this,'ep-num')"/>
              <span class="field-err" id="err-ep-num"></span>
            </div>
            <div style="padding:10px 12px;background:#F0FDF4;border-radius:var(--r);font-size:13px;color:var(--green)">
              ✓ You will receive a confirmation SMS on this number to complete payment
            </div>
          </div>

          <div id="jc-fields" class="card-fields" style="display:none">
            <div class="field">
              <label>JazzCash Mobile Number *</label>
              <input id="co-jc-num" placeholder="03XX-XXXXXXX" type="tel" maxlength="15"
                oninput="clearErr(this);formatPhone(this)" onblur="validatePhone(this,'jc-num')"/>
              <span class="field-err" id="err-jc-num"></span>
            </div>
            <div style="padding:10px 12px;background:#FEF3C7;border-radius:var(--r);font-size:13px;color:var(--amber)">
              ⚡ You will receive a JazzCash PIN prompt on this number to complete payment
            </div>
          </div>

          <div id="cod-fields" class="card-fields" style="display:none">
            <div style="padding:14px 16px;background:#F0FDF4;border-radius:var(--r);font-size:14px;color:var(--green);line-height:1.6">
              ✓ <strong>Cash on Delivery selected.</strong><br/>
              No advance payment required. Our delivery agent will collect payment when your order arrives.
            </div>
          </div>
        </div>

        <button class="btn-primary fw" id="place-btn" onclick="placeOrder()" style="padding:15px;font-size:15px;margin-top:8px">
          Place Order — $${total.toFixed(2)}
        </button>
        <p style="font-size:12px;color:var(--text3);text-align:center;margin-top:10px">
          🔒 Your payment information is encrypted and secure
        </p>
      </div>

      <div class="order-sidebar">
        <div class="order-box">
          <div class="order-box-title">Order Summary</div>
          ${orderItems}
          <div class="ob-totals">
            <div class="ob-row"><span>Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
            <div class="ob-row"><span>Shipping</span><span>${shipping === 0 ? '<span style="color:var(--green)">Free</span>' : '$'+shipping.toFixed(2)}</span></div>
            <div class="ob-row"><span>Tax (8%)</span><span>$${tax.toFixed(2)}</span></div>
            <div class="ob-row total"><span>Total</span><span>$${total.toFixed(2)}</span></div>
          </div>
        </div>
        ${shipping > 0 ? `<p style="font-size:12px;color:var(--text3);text-align:center;margin-top:10px">Add $${(75-subtotal).toFixed(2)} more for free shipping</p>` : ''}
      </div>
    </div>
  `;
  selectedPayment = 'card';
}

/* ── Payment toggle — shows ONLY the selected method's fields ── */
function selectPayment(method) {
  selectedPayment = method;

  // Toggle selected style on options
  ['card','easypaisa','jazzcash','cash'].forEach(m => {
    const opt = document.getElementById(`pm-${m}`);
    if (opt) opt.classList.toggle('selected', m === method);
    // Sync radio button
    const radio = opt ? opt.querySelector('input[type=radio]') : null;
    if (radio) radio.checked = (m === method);
  });

  // Hide ALL payment detail panels first
  const allPanels = ['card-fields','ep-fields','jc-fields','cod-fields'];
  allPanels.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  // Show ONLY the matching panel
  const map = { card:'card-fields', easypaisa:'ep-fields', jazzcash:'jc-fields', cash:'cod-fields' };
  const show = document.getElementById(map[method]);
  if (show) show.style.display = 'block';
}

/* ── Field formatters ── */
function formatCard(input) {
  let v = input.value.replace(/\D/g,'').slice(0,16);
  input.value = v.replace(/(\d{4})(?=\d)/g,'$1 ');
}
function formatExpiry(input) {
  let v = input.value.replace(/\D/g,'').slice(0,4);
  if (v.length >= 2) v = v.slice(0,2) + '/' + v.slice(2);
  input.value = v;
}
function formatPhone(input) {
  let v = input.value.replace(/[^\d\-]/g,'');
  input.value = v;
}

/* ── Field validators (inline, called on blur) ── */
function clearErr(input) {
  const errId = 'err-' + input.id.replace('co-','');
  const errEl = document.getElementById(errId);
  if (errEl) errEl.textContent = '';
  input.style.borderColor = '';
}
function showFieldErr(inputId, msg) {
  const input = document.getElementById(inputId);
  const errEl = document.getElementById('err-' + inputId.replace('co-',''));
  if (input) input.style.borderColor = 'var(--red)';
  if (errEl) errEl.textContent = msg;
  return false;
}
function validateRequired(input, label) {
  if (!input.value.trim()) { showFieldErr(input.id, `${label} is required`); return false; }
  return true;
}
function validateName(input, label) {
  const v = input.value.trim();
  if (!v) return showFieldErr(input.id, `${label} is required`);
  if (v.length < 2) return showFieldErr(input.id, `${label} must be at least 2 characters`);
  if (/\d/.test(v)) return showFieldErr(input.id, `${label} cannot contain numbers`);
  return true;
}
function validateEmail(input) {
  const v = input.value.trim();
  if (!v) return showFieldErr(input.id, 'Email address is required');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return showFieldErr(input.id, 'Please enter a valid email address');
  return true;
}
function validatePhone(input, errSuffix) {
  const v = input.value.replace(/\D/g,'');
  const errKey = errSuffix ? `co-${errSuffix}` : input.id;
  if (!v) { showFieldErr(errKey || input.id, 'Phone number is required'); return false; }
  if (v.length < 10 || v.length > 13) { showFieldErr(errKey || input.id, 'Enter a valid phone number (10-13 digits)'); return false; }
  return true;
}
function validateZip(input) {
  const v = input.value.trim();
  if (!v) return showFieldErr(input.id, 'Postal code is required');
  if (v.length < 4) return showFieldErr(input.id, 'Enter a valid postal code');
  return true;
}
function validateCardNumber(input) {
  const v = input.value.replace(/\s/g,'');
  if (!v) return showFieldErr(input.id, 'Card number is required');
  if (!/^\d{16}$/.test(v)) return showFieldErr(input.id, 'Card number must be 16 digits');
  return true;
}
function validateExpiry(input) {
  const v = input.value.trim();
  if (!v) return showFieldErr(input.id, 'Expiry date is required');
  if (!/^\d{2}\/\d{2}$/.test(v)) return showFieldErr(input.id, 'Use MM/YY format');
  const [mm, yy] = v.split('/').map(Number);
  if (mm < 1 || mm > 12) return showFieldErr(input.id, 'Invalid month');
  const now = new Date(); const curYear = now.getFullYear() % 100; const curMon = now.getMonth() + 1;
  if (yy < curYear || (yy === curYear && mm < curMon)) return showFieldErr(input.id, 'Card has expired');
  return true;
}
function validateCVV(input) {
  const v = input.value.trim();
  if (!v) return showFieldErr(input.id, 'CVV is required');
  if (!/^\d{3}$/.test(v)) return showFieldErr(input.id, 'CVV must be exactly 3 digits');
  return true;
}

/* ── Full checkout validation before placing order ── */
function validateCheckout() {
  const errs = [];

  // Contact
  const fname = document.getElementById('co-fname');
  const email = document.getElementById('co-email');
  const phone = document.getElementById('co-phone');
  if (!validateName(fname, 'First name')) errs.push('first name');
  if (!validateEmail(email)) errs.push('email');
  if (!validatePhone(phone)) errs.push('phone');

  // Address
  const addr = document.getElementById('co-addr');
  const city = document.getElementById('co-city');
  const zip  = document.getElementById('co-zip');
  if (!validateRequired(addr, 'Street address')) errs.push('address');
  if (!validateRequired(city, 'City')) errs.push('city');
  if (!validateZip(zip)) errs.push('postal code');

  // Payment — only validate the visible method
  if (selectedPayment === 'card') {
    if (!validateCardNumber(document.getElementById('co-card'))) errs.push('card number');
    if (!validateExpiry(document.getElementById('co-expiry'))) errs.push('expiry');
    if (!validateCVV(document.getElementById('co-cvv'))) errs.push('CVV');
    if (!validateRequired(document.getElementById('co-cardname'), 'Name on card')) errs.push('card name');
  }
  if (selectedPayment === 'easypaisa') {
    const epNum = document.getElementById('co-ep-num');
    if (!validatePhone(epNum, 'ep-num')) errs.push('EasyPaisa number');
  }
  if (selectedPayment === 'jazzcash') {
    const jcNum = document.getElementById('co-jc-num');
    if (!validatePhone(jcNum, 'jc-num')) errs.push('JazzCash number');
  }
  // Cash on delivery — no extra fields

  if (errs.length > 0) {
    showToast(`Please fix the highlighted fields`, 'error');
    // Scroll to first error
    const firstErr = document.querySelector('.field input[style*="red"]');
    if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return false;
  }
  return true;
}

async function placeOrder() {
  if (!currentUser || cart.length === 0) return;
  if (!validateCheckout()) return;

  const btn = document.getElementById('place-btn');
  btn.disabled = true;
  btn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-color:rgba(255,255,255,.3);border-top-color:#fff;display:inline-block;margin-right:8px"></div> Processing…';

  const results = [];
  let backendDown = false;

  for (const { product, qty } of cart) {
    try {
      const order = await OrderAPI.place({ user_id: currentUser.id, product_id: product.id, quantity: qty });
      results.push({ ok: true, order, product, qty });
    } catch (e) {
      // Distinguish: network error (backend down) vs payment declined (backend responded)
      const isNetworkError = e.message.includes('not reachable') || e.message.includes('fetch') || e.message.includes('Failed to fetch') || e.message.includes('NetworkError');
      if (isNetworkError) backendDown = true;
      results.push({ ok: false, error: e.message, networkError: isNetworkError, product, qty });
    }
  }

  const allOk  = results.every(r => r.ok && r.order?.order_status === 'CONFIRMED');
  const anyOk  = results.some(r => r.ok && r.order?.order_status === 'CONFIRMED');
  const lastOk = results.find(r => r.ok) || results[0];

  // If ALL failed due to network — don't clear cart, let them retry
  if (backendDown && !anyOk) {
    const btn = document.getElementById('place-btn');
    if (btn) { btn.disabled = false; btn.textContent = `Place Order — $${(cartTotal()*1.08 + (cartTotal()>=75?0:9.99)).toFixed(2)}`; }
    showToast('Cannot reach the backend — make sure Docker is running', 'error');
    return;
  }

  cartClear();
  productsCache = [];
  goTo('confirm');
  renderConfirm(results, allOk, anyOk, lastOk, backendDown);
}

/* ════════════════════ CONFIRM ════════════════════ */
function renderConfirm(results, allOk, anyOk, lastOk, backendDown) {
  const el = document.getElementById('page-confirm');
  const payMethodLabel = selectedPayment === 'cash' ? 'Cash on Delivery'
    : selectedPayment === 'card' ? 'Credit / Debit Card'
    : selectedPayment === 'easypaisa' ? 'EasyPaisa'
    : selectedPayment === 'jazzcash' ? 'JazzCash' : selectedPayment;

  // ── All payment declined (backend responded but payment service said FAILED) ──
  if (!anyOk && !backendDown) {
    el.innerHTML = renderNavbar('') + `
      <div class="confirm-wrap">
        <div class="confirm-icon confirm-fail">✕</div>
        <div class="confirm-title" style="color:var(--red)">Payment Declined</div>
        <p class="confirm-sub">
          Your payment was declined by the payment processor.<br/>
          <strong>This is a simulation</strong> — the Payment Service randomly declines ~20% of transactions to mimic real-world failures. No actual charge was made.
        </p>
        <div class="confirm-card">
          ${results.map(r => `
            <div class="cc-row">
              <span class="cc-label">${r.product.name} × ${r.qty}</span>
              <span class="cc-val" style="color:var(--red)">✕ Declined — $${(r.product.price * r.qty).toFixed(2)}</span>
            </div>`).join('')}
          <div class="cc-row">
            <span class="cc-label">Payment method</span>
            <span class="cc-val">${payMethodLabel}</span>
          </div>
          <div class="cc-row">
            <span class="cc-label">Charged</span>
            <span class="cc-val" style="color:var(--green)">$0.00 — nothing deducted</span>
          </div>
        </div>
        <div style="background:#FEF3C7;border-radius:var(--r);padding:14px 18px;margin-bottom:24px;font-size:13px;color:var(--amber);text-align:left;max-width:480px;margin-left:auto;margin-right:auto">
          <strong>Why did this happen?</strong><br/>
          The Payment Simulation Service (running on port 8004) is intentionally designed to decline 20% of all transactions. Simply click "Try Again" — it will likely succeed next time. This behaviour is part of the distributed system demo.
        </div>
        <div class="confirm-btns">
          <button class="btn-primary" onclick="retryCheckout()" style="background:var(--text)">Try Again →</button>
          <button class="btn-ghost" onclick="goTo('products')">Continue Shopping</button>
        </div>
      </div>
    `;
    return;
  }

  // ── All confirmed ──
  const total = results.reduce((s,r) => s + (r.order ? r.order.total_price : 0), 0);
  el.innerHTML = renderNavbar('') + `
    <div class="confirm-wrap">
      <div class="confirm-icon ${allOk ? 'confirm-ok' : 'confirm-fail'}">${allOk ? '✓' : '⚠'}</div>
      <div class="confirm-title" style="color:${allOk ? 'var(--green)' : 'var(--amber)'}">
        ${allOk ? 'Order Confirmed!' : 'Partially Confirmed'}
      </div>
      <p class="confirm-sub">
        ${allOk
          ? `Your order has been placed and is being prepared for shipment.`
          : `${results.filter(r=>r.ok&&r.order?.order_status==='CONFIRMED').length} of ${results.length} items confirmed. Some payments were declined.`}
      </p>
      <div class="confirm-card">
        ${results.map(r => {
          const confirmed = r.ok && r.order?.order_status === 'CONFIRMED';
          return `
            <div class="cc-row">
              <span class="cc-label">${r.product.name} × ${r.qty}</span>
              <span class="cc-val" style="color:${confirmed ? 'var(--green)' : 'var(--red)'}">
                ${confirmed ? '✓ Confirmed — $'+r.order.total_price.toFixed(2) : '✕ Declined'}
              </span>
            </div>`;
        }).join('')}
        ${lastOk?.order ? `
          <div class="cc-row"><span class="cc-label">Order #</span><span class="cc-val">#${lastOk.order.id}</span></div>` : ''}
        <div class="cc-row"><span class="cc-label">Payment</span><span class="cc-val">${payMethodLabel}</span></div>
        <div class="cc-row"><span class="cc-label">Total charged</span><span class="cc-val">$${total.toFixed(2)}</span></div>
        <div class="cc-row"><span class="cc-label">Estimated delivery</span><span class="cc-val">3–5 business days</span></div>
      </div>
      <div class="confirm-btns">
        <button class="btn-primary" onclick="goTo('orders')">View My Orders</button>
        <button class="btn-ghost" onclick="goTo('products')">Continue Shopping</button>
      </div>
    </div>
  `;
}

/* Retry: put the items back in cart and go to checkout */
function retryCheckout() {
  // Cart was already cleared — user needs to re-add items
  // Instead just go back to products with a helpful message
  goTo('products');
  showToast('Add your items to cart and try checking out again', 'info');
}

/* ════════════════════ ORDERS ════════════════════ */
async function renderOrders() {
  const el = document.getElementById('page-orders');
  if (!currentUser) {
    el.innerHTML = renderNavbar('orders') + signWall('view your orders');
    return;
  }
  el.innerHTML = renderNavbar('orders') + `
    <div class="orders-wrap">
      <div class="orders-title">My Orders</div>
      <div class="orders-sub">Your order history — ${currentUser.email}</div>
      <div id="orders-list">${loading()}</div>
    </div>
  `;
  try {
    const orders = await OrderAPI.list(currentUser.id);
    const listEl = document.getElementById('orders-list');
    if (!listEl) return;
    if (!orders.length) {
      listEl.innerHTML = `<div class="empty"><span class="big">📋</span><p>No orders yet — <a onclick="goTo('products')" style="text-decoration:underline;cursor:pointer">start shopping</a></p></div>`;
      return;
    }
    // Newest first
    const imgs = productsCache.length ? {} : {};
    listEl.innerHTML = [...orders].reverse().map(o => {
      const isOk = o.order_status === 'CONFIRMED';
      const p = productsCache.find(x => x.id === o.product_id);
      const imgSrc = p ? productImg(p) : (FALLBACK_IMGS[o.product_id] || '');
      const dateStr = o.created_at
        ? new Date(o.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})
        : 'Recently';
      return `
        <div class="order-card">
          <div class="oc-head">
            <div>
              <div class="oc-id">Order #${o.id}</div>
              <div class="oc-date">${dateStr}</div>
            </div>
            <span class="oc-status ${isOk?'oc-confirmed':'oc-failed'}">
              ${isOk ? '✓ Confirmed' : '✕ Payment Failed'}
            </span>
          </div>
          <div class="oc-items">
            ${imgSrc ? `<div class="oc-img"><img src="${imgSrc}" alt="Product" style="object-fit:cover;width:100%;height:100%"/></div>` : ''}
            <div>
              <div style="font-size:14px;font-weight:500">Product #${o.product_id}</div>
              <div style="font-size:13px;color:var(--text3)">Qty: ${o.quantity} · via ${selectedPayment||'Card'}</div>
            </div>
          </div>
          <div class="oc-foot">
            <span class="oc-payment">Payment: ${o.payment_status}</span>
            <span class="oc-total">$${o.total_price.toFixed(2)}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (e) {
    const listEl = document.getElementById('orders-list');
    if (listEl) listEl.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`;
  }
}

/* ════════════════════ ACCOUNT ════════════════════ */
function renderAccount() {
  const el = document.getElementById('page-account');
  if (!currentUser) {
    el.innerHTML = renderNavbar('') + signWall('view your account');
    return;
  }
  el.innerHTML = renderNavbar('') + `
    <div class="account-wrap">
      <div class="account-title">My Account</div>
      <div class="account-section">
        <div class="account-section-title">Profile Information</div>
        <div class="field-row">
          <div class="field"><label>Name</label><input value="${currentUser.name}" readonly style="background:var(--bg3)"/></div>
          <div class="field"><label>Email</label><input value="${currentUser.email}" readonly style="background:var(--bg3)"/></div>
        </div>
        <div class="field"><label>Account ID</label><input value="#${currentUser.id}" readonly style="background:var(--bg3)"/></div>
      </div>
      <div class="account-section">
        <div class="account-section-title">Quick Actions</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn-ghost btn-sm" onclick="goTo('orders')">View Orders</button>
          <button class="btn-ghost btn-sm" onclick="goTo('products')">Continue Shopping</button>
          <button class="btn-ghost btn-sm" onclick="doLogout()" style="color:var(--red);border-color:var(--red)">Sign Out</button>
        </div>
      </div>
    </div>
  `;
}

/* ════════════════════ SIGN IN PAGE ════════════════════ */
function renderSignIn() {
  const el = document.getElementById('page-signin');
  el.innerHTML = `
    <div class="auth-page">
      <div class="auth-page-left">
        <div class="auth-left-content">
          <div class="auth-brand" onclick="goTo('home')">NEXUS</div>
          <div class="auth-headline">Welcome<br/>back.</div>
          <div class="auth-tagline">Sign in to track your orders, manage your account, and pick up where you left off.</div>
        </div>
        <div class="auth-left-foot">
          <div class="auth-trust">
            <div class="auth-trust-item"><span>🔒</span> Secure login</div>
            <div class="auth-trust-item"><span>📦</span> Track orders</div>
            <div class="auth-trust-item"><span>💳</span> Saved preferences</div>
          </div>
        </div>
      </div>
      <div class="auth-page-right">
        <div class="auth-form-box">
          <div class="auth-form-title">Sign In</div>
          <div class="auth-form-sub">Enter your email and password to continue</div>

          <div class="field">
            <label>Email address</label>
            <input type="email" id="si-email" placeholder="you@example.com" autocomplete="email"
              oninput="clearFieldErr('si-email')" onkeydown="if(event.key==='Enter')doSignIn()"/>
            <span class="field-err" id="err-si-email"></span>
          </div>
          <div class="field">
            <label>Password</label>
            <input type="password" id="si-pass" placeholder="Your password" autocomplete="current-password"
              oninput="clearFieldErr('si-pass')" onkeydown="if(event.key==='Enter')doSignIn()"/>
            <span class="field-err" id="err-si-pass"></span>
          </div>

          <button class="btn-primary fw" id="si-btn" onclick="doSignIn()" style="padding:13px;font-size:15px;margin-top:8px">
            Sign In
          </button>

          <div class="auth-bottom-link">
            Don't have an account? <a onclick="goTo('register')">Create one free</a>
          </div>
          <div class="auth-bottom-link" style="margin-top:10px">
            <a onclick="goTo('home')" style="color:var(--text3);font-weight:400;text-decoration:none">&#8592; Back to store</a>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* ════════════════════ REGISTER PAGE ════════════════════ */
function renderRegister() {
  const el = document.getElementById('page-register');
  el.innerHTML = `
    <div class="auth-page">
      <div class="auth-page-left">
        <div class="auth-left-content">
          <div class="auth-brand" onclick="goTo('home')">NEXUS</div>
          <div class="auth-headline">Join<br/>NEXUS.</div>
          <div class="auth-tagline">Create your free account and get access to exclusive deals, order tracking, and faster checkout every time.</div>
        </div>
        <div class="auth-left-foot">
          <div class="auth-trust">
            <div class="auth-trust-item"><span>🚚</span> Free shipping over $75</div>
            <div class="auth-trust-item"><span>↩</span> 30-day returns</div>
            <div class="auth-trust-item"><span>🎁</span> Member-only deals</div>
          </div>
        </div>
      </div>
      <div class="auth-page-right">
        <div class="auth-form-box">
          <div class="auth-form-title">Create Account</div>
          <div class="auth-form-sub">It's free and only takes a minute</div>

          <div class="field-row">
            <div class="field">
              <label>First name *</label>
              <input type="text" id="su-fname" placeholder="Alice" autocomplete="given-name"
                oninput="clearFieldErr('su-fname')" onblur="validateRegName()"/>
              <span class="field-err" id="err-su-fname"></span>
            </div>
            <div class="field">
              <label>Last name</label>
              <input type="text" id="su-lname" placeholder="Smith" autocomplete="family-name"/>
            </div>
          </div>
          <div class="field">
            <label>Email address *</label>
            <input type="email" id="su-email" placeholder="you@example.com" autocomplete="email"
              oninput="clearFieldErr('su-email')" onblur="validateRegEmail()"/>
            <span class="field-err" id="err-su-email"></span>
          </div>
          <div class="field">
            <label>Password *</label>
            <input type="password" id="su-pass" placeholder="At least 6 characters" autocomplete="new-password"
              oninput="clearFieldErr('su-pass');updatePasswordStrength()" onblur="validateRegPass()"/>
            <span class="field-err" id="err-su-pass"></span>
            <div id="pass-strength-bar" style="height:3px;border-radius:2px;margin-top:6px;background:var(--border);overflow:hidden;display:none">
              <div id="pass-strength-fill" style="height:100%;width:0%;transition:all .3s;border-radius:2px"></div>
            </div>
            <span id="pass-strength-label" style="font-size:11px;color:var(--text3);margin-top:2px;display:none"></span>
          </div>
          <div class="field">
            <label>Confirm password *</label>
            <input type="password" id="su-pass2" placeholder="Repeat your password" autocomplete="new-password"
              oninput="clearFieldErr('su-pass2')" onblur="validateRegPass2()"/>
            <span class="field-err" id="err-su-pass2"></span>
          </div>

          <button class="btn-primary fw" id="su-btn" onclick="doSignUp()" style="padding:13px;font-size:15px;margin-top:8px">
            Create Account
          </button>

          <div class="auth-bottom-link">
            Already have an account? <a onclick="goTo('signin')">Sign in</a>
          </div>
          <div class="auth-bottom-link" style="margin-top:10px">
            <a onclick="goTo('home')" style="color:var(--text3);font-weight:400;text-decoration:none">&#8592; Back to store</a>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* ── Register inline validators ── */
function validateRegName() {
  const v = document.getElementById('su-fname').value.trim();
  if (!v) return setRegErr('su-fname','First name is required');
  if (v.length < 2) return setRegErr('su-fname','Must be at least 2 characters');
  if (/\d/.test(v)) return setRegErr('su-fname','Cannot contain numbers');
  clearFieldErr('su-fname'); return true;
}
function validateRegEmail() {
  const v = document.getElementById('su-email').value.trim();
  if (!v) return setRegErr('su-email','Email address is required');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return setRegErr('su-email','Please enter a valid email');
  clearFieldErr('su-email'); return true;
}
function validateRegPass() {
  const v = document.getElementById('su-pass').value;
  if (!v) return setRegErr('su-pass','Password is required');
  if (v.length < 6) return setRegErr('su-pass','Must be at least 6 characters');
  if (!/[A-Za-z]/.test(v)) return setRegErr('su-pass','Must contain at least one letter');
  clearFieldErr('su-pass'); return true;
}
function validateRegPass2() {
  const p1 = document.getElementById('su-pass').value;
  const p2 = document.getElementById('su-pass2').value;
  if (!p2) return setRegErr('su-pass2','Please confirm your password');
  if (p1 !== p2) return setRegErr('su-pass2','Passwords do not match');
  clearFieldErr('su-pass2'); return true;
}
function setRegErr(id, msg) {
  const input = document.getElementById(id);
  const err   = document.getElementById('err-' + id);
  if (input) input.style.borderColor = 'var(--red)';
  if (err)   err.textContent = msg;
  return false;
}
function clearFieldErr(id) {
  const input = document.getElementById(id);
  const err   = document.getElementById('err-' + id);
  if (input) input.style.borderColor = '';
  if (err)   err.textContent = '';
}
function updatePasswordStrength() {
  const v    = document.getElementById('su-pass').value;
  const bar  = document.getElementById('pass-strength-bar');
  const fill = document.getElementById('pass-strength-fill');
  const lbl  = document.getElementById('pass-strength-label');
  if (!v) { bar.style.display='none'; lbl.style.display='none'; return; }
  bar.style.display = 'block'; lbl.style.display = 'block';
  let score = 0;
  if (v.length >= 6)  score++;
  if (v.length >= 10) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/\d/.test(v))    score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  const levels = [
    { pct:'20%', color:'var(--red)',   label:'Very weak' },
    { pct:'40%', color:'var(--red)',   label:'Weak' },
    { pct:'60%', color:'var(--amber)', label:'Fair' },
    { pct:'80%', color:'var(--amber)', label:'Good' },
    { pct:'100%',color:'var(--green)', label:'Strong' },
  ];
  const lvl = levels[Math.min(score, 4)];
  fill.style.width = lvl.pct;
  fill.style.background = lvl.color;
  lbl.textContent = lvl.label;
  lbl.style.color = lvl.color;
}