/* admin.js — full admin panel */

/* Admin is only accessible to admin@nexus.com */
function isAdmin() { return currentUser && currentUser.email === 'admin@nexus.com'; }

let adminSection = 'dashboard';

async function renderAdmin() {
  const el = document.getElementById('page-admin');
  if (!currentUser) { el.innerHTML = renderNavbar('admin') + signWall('access admin'); return; }
  if (!isAdmin()) {
    el.innerHTML = renderNavbar('admin') + `
      <div class="empty" style="padding-top:80px">
        <span class="big">🔒</span>
        <p>Admin access required.<br/><small style="color:var(--text3)">Sign in as admin@nexus.com</small></p>
      </div>`;
    return;
  }

  el.innerHTML = renderNavbar('admin') + `
    <div class="admin-layout">
      <div class="admin-sidebar">
        <div style="padding:0 0 20px;border-bottom:1px solid var(--border);margin-bottom:8px">
          <div style="padding:16px 20px;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--text3)">Admin Panel</div>
        </div>
        <div class="admin-menu-item ${adminSection==='dashboard'?'active':''}" onclick="switchAdmin('dashboard')">
          <span class="admin-menu-icon">📊</span> Dashboard
        </div>
        <div class="admin-menu-item ${adminSection==='products'?'active':''}" onclick="switchAdmin('products')">
          <span class="admin-menu-icon">📦</span> Products
        </div>
        <div class="admin-menu-item ${adminSection==='orders'?'active':''}" onclick="switchAdmin('orders')">
          <span class="admin-menu-icon">🧾</span> All Orders
        </div>
        <div class="admin-menu-item ${adminSection==='users'?'active':''}" onclick="switchAdmin('users')">
          <span class="admin-menu-icon">👥</span> Customers
        </div>
      </div>
      <div class="admin-main" id="admin-main">
        ${loading()}
      </div>
    </div>
  `;

  await loadAdminSection(adminSection);
}

async function switchAdmin(section) {
  adminSection = section;
  document.querySelectorAll('.admin-menu-item').forEach(i => {
    i.classList.toggle('active', i.textContent.trim().toLowerCase().includes(section.replace('dashboard','dash')));
  });
  const main = document.getElementById('admin-main');
  if (main) { main.innerHTML = loading(); }
  await loadAdminSection(section);
}

async function loadAdminSection(section) {
  const main = document.getElementById('admin-main');
  if (!main) return;

  if (section === 'dashboard') {
    try {
      const [products, orders, users] = await Promise.all([
        ProductAPI.list(), OrderAPI.list(), UserAPI.list()
      ]);
      const confirmed = orders.filter(o => o.order_status === 'CONFIRMED');
      const revenue   = confirmed.reduce((s, o) => s + o.total_price, 0);
      const customers = users.filter(u => u.email !== 'admin@nexus.com');
      main.innerHTML = `
        <div class="admin-page-title">Dashboard</div>
        <div class="admin-page-sub">Overview of your store performance</div>
        <div class="admin-stats">
          <div class="astat">
            <div class="astat-label">Total Revenue</div>
            <div class="astat-val">$${revenue.toFixed(0)}</div>
            <div class="astat-sub">from confirmed orders</div>
          </div>
          <div class="astat">
            <div class="astat-label">Total Orders</div>
            <div class="astat-val">${orders.length}</div>
            <div class="astat-sub">${confirmed.length} confirmed</div>
          </div>
          <div class="astat">
            <div class="astat-label">Products</div>
            <div class="astat-val">${products.length}</div>
            <div class="astat-sub">in catalog</div>
          </div>
          <div class="astat">
            <div class="astat-label">Customers</div>
            <div class="astat-val">${customers.length}</div>
            <div class="astat-sub">registered accounts</div>
          </div>
        </div>
        <div class="admin-table-wrap">
          <div class="admin-table-head">
            <div class="admin-table-title">Recent Orders</div>
          </div>
          <table>
            <thead><tr>
              <th>Order #</th><th>Product</th><th>Qty</th><th>Total</th><th>Payment</th><th>Status</th>
            </tr></thead>
            <tbody>
              ${[...orders].reverse().slice(0,10).map(o => `
                <tr>
                  <td>#${o.id}</td>
                  <td>Product #${o.product_id}</td>
                  <td>${o.quantity}</td>
                  <td>$${o.total_price.toFixed(2)}</td>
                  <td><span style="font-size:11px;color:var(--text3)">${o.payment_status}</span></td>
                  <td><span class="badge-pill ${o.order_status==='CONFIRMED'?'':'badge-fail-pill'}"
                    style="background:${o.order_status==='CONFIRMED'?'#DCFCE7':'#FEE2E2'};color:${o.order_status==='CONFIRMED'?'var(--green)':'var(--red)'}">
                    ${o.order_status}
                  </span></td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch(e) { main.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`; }

  } else if (section === 'products') {
    try {
      const products = await loadProducts(true);
      main.innerHTML = `
        <div class="admin-page-title">Products</div>
        <div class="admin-page-sub">Manage your product catalog</div>
        <div class="admin-table-wrap">
          <div class="admin-table-head">
            <div class="admin-table-title">All Products (${products.length})</div>
            <button class="btn-primary btn-sm" onclick="openAddProduct()">+ Add Product</button>
          </div>
          <table>
            <thead><tr>
              <th>Image</th><th>Name</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th>
            </tr></thead>
            <tbody>
              ${products.map(p => `
                <tr>
                  <td>
                    <div class="td-img-cell">
                      <div class="td-img">
                        <img src="${productImg(p)}" alt="${p.name}" style="object-fit:cover;width:100%;height:100%"
                          onerror="this.style.display='none'"/>
                      </div>
                    </div>
                  </td>
                  <td>${p.name}</td>
                  <td>$${p.price.toFixed(2)}</td>
                  <td>${p.stock}</td>
                  <td>
                    <span class="badge-pill" style="background:${p.stock===0?'#FEE2E2':p.stock<=5?'#FEF3C7':'#DCFCE7'};color:${p.stock===0?'var(--red)':p.stock<=5?'var(--amber)':'var(--green)'}">
                      ${p.stock===0?'Out of Stock':p.stock<=5?'Low Stock':'In Stock'}
                    </span>
                  </td>
                  <td>
                    <button class="btn-xs btn-ghost" onclick="openEditImage(${p.id},'${p.name}')">📷 Image</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch(e) { main.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`; }

  } else if (section === 'orders') {
    try {
      const orders = await OrderAPI.list();
      main.innerHTML = `
        <div class="admin-page-title">All Orders</div>
        <div class="admin-page-sub">${orders.length} total orders across all customers</div>
        <div class="admin-table-wrap">
          <table>
            <thead><tr>
              <th>Order #</th><th>User</th><th>Product</th><th>Qty</th><th>Total</th><th>Payment</th><th>Status</th>
            </tr></thead>
            <tbody>
              ${[...orders].reverse().map(o => `
                <tr>
                  <td>#${o.id}</td>
                  <td>User #${o.user_id}</td>
                  <td>Product #${o.product_id}</td>
                  <td>${o.quantity}</td>
                  <td>$${o.total_price.toFixed(2)}</td>
                  <td style="font-size:12px;color:var(--text3)">${o.payment_status}</td>
                  <td><span style="font-size:11px;padding:3px 8px;border-radius:99px;background:${o.order_status==='CONFIRMED'?'#DCFCE7':'#FEE2E2'};color:${o.order_status==='CONFIRMED'?'var(--green)':'var(--red)'}">
                    ${o.order_status}
                  </span></td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch(e) { main.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`; }

  } else if (section === 'users') {
    try {
      const allUsers = await UserAPI.list();
      // Admin is not a customer — exclude from this list
      const users = allUsers.filter(u => u.email !== 'admin@nexus.com');
      main.innerHTML = `
        <div class="admin-page-title">Customers</div>
        <div class="admin-page-sub">${users.length} registered customer account${users.length !== 1 ? 's' : ''}</div>
        <div class="admin-table-wrap">
          <table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th></tr></thead>
            <tbody>
              ${users.length === 0
                ? `<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--text3)">No customers yet</td></tr>`
                : users.map(u => `
                <tr>
                  <td>#${u.id}</td>
                  <td>${u.name}</td>
                  <td style="color:var(--text2)">${u.email}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch(e) { main.innerHTML = `<div class="empty"><p>⚠ ${e.message}</p></div>`; }
  }
}

/* ── Add Product Modal ── */
let newProductImageData = null;

function openAddProduct() {
  newProductImageData = null;
  const modal = document.createElement('div');
  modal.className = 'modal-backdrop';
  modal.id = 'add-product-modal';
  modal.innerHTML = `
    <div class="modal">
      <button class="close-btn modal-close" onclick="document.getElementById('add-product-modal').remove()">✕</button>
      <div class="modal-title">Add New Product</div>

      <div id="img-upload-box" class="img-upload-box" onclick="document.getElementById('img-file-input').click()">
        <div style="font-size:36px">📷</div>
        <div class="img-upload-label">Click to upload product image</div>
        <div class="img-upload-hint">JPG, PNG or WebP · Recommended 3:4 ratio</div>
      </div>
      <input type="file" id="img-file-input" accept="image/*" style="display:none" onchange="handleImgUpload(event)"/>

      <div class="field"><label>Product Name *</label><input id="np-name" placeholder="e.g. Gaming Mouse"/></div>
      <div class="field"><label>Description</label><textarea id="np-desc" rows="2" placeholder="Brief description of the product" style="padding:10px;border:1.5px solid var(--border2);border-radius:var(--r);resize:vertical;font-size:14px"></textarea></div>
      <div class="field-row">
        <div class="field"><label>Price (USD) *</label><input id="np-price" type="number" step="0.01" placeholder="0.00"/></div>
        <div class="field"><label>Initial Stock *</label><input id="np-stock" type="number" placeholder="0"/></div>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px">
        <button class="btn-primary fw" onclick="submitNewProduct()">Add Product</button>
        <button class="btn-ghost" onclick="document.getElementById('add-product-modal').remove()">Cancel</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
}

function handleImgUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    newProductImageData = e.target.result;
    const box = document.getElementById('img-upload-box');
    if (box) {
      box.classList.add('has-img');
      box.innerHTML = `<img src="${newProductImageData}" alt="Preview"/>`;
    }
  };
  reader.readAsDataURL(file);
}

async function submitNewProduct() {
  const name  = document.getElementById('np-name')?.value.trim();
  const desc  = document.getElementById('np-desc')?.value.trim();
  const price = parseFloat(document.getElementById('np-price')?.value);
  const stock = parseInt(document.getElementById('np-stock')?.value);

  if (!name || isNaN(price) || isNaN(stock)) { showToast('Please fill in all required fields', 'error'); return; }
  if (price <= 0) { showToast('Price must be greater than 0', 'error'); return; }
  if (stock < 0)  { showToast('Stock cannot be negative', 'error'); return; }

  try {
    const product = await ProductAPI.create({ name, description: desc, price, stock });
    if (newProductImageData) saveProductImage(product.id, newProductImageData);
    productsCache = [];
    document.getElementById('add-product-modal')?.remove();
    showToast(`"${product.name}" added successfully!`, 'success');
    await switchAdmin('products');
  } catch (e) {
    showToast(e.message, 'error');
  }
}

/* ── Edit product image ── */
function openEditImage(productId, productName) {
  const modal = document.createElement('div');
  modal.className = 'modal-backdrop';
  modal.id = 'edit-img-modal';
  modal.innerHTML = `
    <div class="modal">
      <button class="close-btn modal-close" onclick="document.getElementById('edit-img-modal').remove()">✕</button>
      <div class="modal-title">Update Image — ${productName}</div>
      <div id="edit-img-box" class="img-upload-box" onclick="document.getElementById('edit-img-input').click()">
        ${getProductImage(productId)
          ? `<img src="${getProductImage(productId)}" style="width:100%;height:200px;object-fit:contain"/>`
          : `<div style="font-size:36px">📷</div><div class="img-upload-label">Click to upload new image</div>`}
      </div>
      <input type="file" id="edit-img-input" accept="image/*" style="display:none" onchange="applyEditImage(event,${productId})"/>
      <button class="btn-ghost fw" onclick="document.getElementById('edit-img-modal').remove()" style="margin-top:10px">Cancel</button>
    </div>
  `;
  document.body.appendChild(modal);
}

function applyEditImage(event, productId) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    saveProductImage(productId, e.target.result);
    document.getElementById('edit-img-modal')?.remove();
    showToast('Product image updated!', 'success');
    switchAdmin('products');
  };
  reader.readAsDataURL(file);
}
