/* app.js — router and boot */

const ALL_PAGES = ['home','products','product','cart','checkout','confirm','orders','admin','account','signin','register'];

let currentPage = 'home';
let currentParam = null;

function goTo(page, param) {
  currentPage = page;
  currentParam = param || null;

  ALL_PAGES.forEach(p => {
    const el = document.getElementById(`page-${p}`);
    if (el) el.classList.remove('active');
  });

  closeCart();
  window.scrollTo({ top: 0, behavior: 'instant' });

  const target = document.getElementById(`page-${page}`);
  if (target) target.classList.add('active');

  switch (page) {
    case 'home':     renderHome();                break;
    case 'products': renderProducts(param);       break;
    case 'product':  renderProductDetail(param);  break;
    case 'checkout': renderCheckout();            break;
    case 'confirm':  /* rendered by placeOrder */ break;
    case 'orders':   renderOrders();              break;
    case 'admin':    renderAdmin();               break;
    case 'account':  renderAccount();             break;
    case 'signin':   renderSignIn();              break;
    case 'register': renderRegister();            break;
  }
}

/* seed admin account locally so it exists in the backend */
async function ensureAdminUser() {
  try {
    const users = await UserAPI.list();
    const hasAdmin = users.some(u => u.email === 'admin@nexus.com');
    if (!hasAdmin) {
      await UserAPI.create({
        name: 'Admin',
        email: 'admin@nexus.com',
        password: 'admin123'
      });
    }
  } catch {}
}

async function init() {
  restoreUser();
  goTo('home');
  ensureAdminUser();
}

document.addEventListener('DOMContentLoaded', init);
