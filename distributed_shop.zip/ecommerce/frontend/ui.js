/* ui.js — shared UI components */

/* ── Toast ── */
function showToast(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  el.innerHTML = `<span style="font-size:15px;font-weight:700">${icons[type]||'·'}</span><span>${msg}</span>`;
  document.getElementById('toast-root').appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s, transform .3s';
    el.style.opacity = '0'; el.style.transform = 'translateX(20px)';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

/* ── Navbar ── */
function renderNavbar(activePage) {
  const pages = document.querySelectorAll('.page.active');
  if (pages.length) {
    const pid = pages[0].id.replace('page-', '');
    activePage = activePage || pid;
  }

  const adminUser = currentUser && currentUser.email === 'admin@nexus.com';

  /* Admin gets completely different navbar — no shop, no cart */
  if (adminUser) {
    return `
      <nav class="navbar">
        <div class="nav-logo" onclick="goTo('admin')">NEXUS <span style="font-size:11px;font-weight:400;color:var(--text3);letter-spacing:.06em">ADMIN</span></div>
        <div class="nav-cats">
          <span class="nav-cat ${activePage==='admin'?'active':''}" onclick="goTo('admin')">⚙ Dashboard</span>
        </div>
        <div class="nav-right">
          <div style="display:flex;align-items:center;gap:8px">
            <div class="nav-avatar">A</div>
            <span style="font-size:13px;font-weight:500">Admin</span>
          </div>
          <button class="nav-btn btn-sm btn-ghost" onclick="doLogout()" style="padding:6px 12px;font-size:13px">Sign Out</button>
        </div>
      </nav>
    `;
  }

  /* Customer navbar */
  const cats = [
    { id:'products', label:'Shop' },
    { id:'orders',   label:'My Orders' },
  ];
  const catLinks = cats.map(c =>
    `<span class="nav-cat ${activePage===c.id?'active':''}" onclick="goTo('${c.id}')">${c.label}</span>`
  ).join('');

  const userSection = currentUser
    ? `<div class="nav-user-name" style="display:flex;align-items:center;gap:8px;cursor:pointer" onclick="goTo('account')">
        <div class="nav-avatar">${currentUser.name[0].toUpperCase()}</div>
        <span>${currentUser.name.split(' ')[0]}</span>
       </div>
       <button class="nav-btn btn-sm btn-ghost" onclick="doLogout()" style="padding:6px 12px;font-size:13px">Sign Out</button>`
    : `<button class="nav-btn" onclick="goTo('signin')">Sign In</button>
       <button class="btn-primary btn-sm" onclick="goTo('register')">Register</button>`;

  return `
    <div class="announce">Free shipping on orders over $75 · <a onclick="goTo('products')">Shop Now</a></div>
    <nav class="navbar">
      <div class="nav-logo" onclick="goTo('home')">NEXUS</div>
      <div class="nav-cats">${catLinks}</div>
      <div class="nav-right">
        ${userSection}
        <button class="nav-btn cart-nav-btn" onclick="openCart()">
          <span>🛒</span><span>Cart</span>
          <span class="cart-badge ${cartCount()>0?'show':''}" id="cart-badge">${cartCount()}</span>
        </button>
      </div>
    </nav>
  `;
}

function updateCartBadge() {
  document.querySelectorAll('.cart-badge, #cart-badge').forEach(el => {
    const n = cartCount();
    el.textContent = n;
    el.classList.toggle('show', n > 0);
  });
}

/* ── Cart Drawer ── */
function openCart() {
  document.getElementById('cart-overlay').classList.add('open');
  document.getElementById('cart-drawer').classList.add('open');
  renderCartDrawer();
}
function closeCart() {
  document.getElementById('cart-overlay').classList.remove('open');
  document.getElementById('cart-drawer').classList.remove('open');
}
function renderCartDrawer() {
  const body = document.getElementById('cart-body');
  const foot = document.getElementById('cart-foot');
  const countEl = document.getElementById('cart-count-label');
  const totalEl = document.getElementById('cart-total-display');
  if (!body) return;

  if (cart.length === 0) {
    body.innerHTML = `<div class="cart-empty"><div class="cart-empty-icon">🛒</div><p>Your cart is empty</p></div>`;
    foot && foot.classList.add('hidden');
    return;
  }

  body.innerHTML = cart.map(({ product, qty }) => `
    <div class="dc-item">
      <div class="dc-img"><img src="${productImg(product)}" alt="${product.name}" style="object-fit:cover;width:100%;height:100%"/></div>
      <div class="dc-info">
        <div class="dc-name">${product.name}</div>
        <div class="dc-sub">$${product.price.toFixed(2)} each</div>
        <div class="dc-row">
          <div class="mini-qty">
            <button onclick="cartSetQty(${product.id}, ${qty-1});renderCartDrawer()">−</button>
            <span>${qty}</span>
            <button onclick="cartSetQty(${product.id}, ${qty+1});renderCartDrawer()">+</button>
          </div>
          <span class="dc-remove" onclick="cartRemove(${product.id});renderCartDrawer()">Remove</span>
          <span class="dc-price">$${(product.price * qty).toFixed(2)}</span>
        </div>
      </div>
    </div>
  `).join('');

  foot && foot.classList.remove('hidden');
  if (countEl) countEl.textContent = cartCount();
  if (totalEl) totalEl.textContent = '$' + cartTotal().toFixed(2);
}

/* ── Auth — now full pages, not a modal ── */
function openAuth(tab) {
  goTo(tab === 'up' ? 'register' : 'signin');
}
function closeAuth() {
  goTo('home');
}
function switchAuthTab(tab) {
  goTo(tab === 'up' ? 'register' : 'signin');
}

async function doSignIn() {
  const email = document.getElementById('si-email')?.value.trim();
  const pass  = document.getElementById('si-pass')?.value;
  const btn   = document.getElementById('si-btn');

  // Validation
  let ok = true;
  if (!email) {
    setSignInErr('si-email', 'Email address is required'); ok = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setSignInErr('si-email', 'Please enter a valid email address'); ok = false;
  }
  if (!pass) {
    setSignInErr('si-pass', 'Password is required'); ok = false;
  }
  if (!ok) return;

  btn.disabled = true; btn.textContent = 'Signing in…';
  try {
    const users = await UserAPI.list();
    const found = users.find(u => u.email === email.toLowerCase());
    if (!found) { setSignInErr('si-email', 'No account found with this email'); return; }
    setUser(found);
    showToast(`Welcome back, ${found.name.split(' ')[0]}!`, 'success');
    goTo(found.email === 'admin@nexus.com' ? 'admin' : 'home');
  } catch (e) {
    showToast(e.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Sign In'; }
  }
}

function setSignInErr(id, msg) {
  const input = document.getElementById(id);
  const err   = document.getElementById('err-' + id);
  if (input) input.style.borderColor = 'var(--red)';
  if (err)   err.textContent = msg;
}

async function doSignUp() {
  const fname = document.getElementById('su-fname')?.value.trim();
  const lname = document.getElementById('su-lname')?.value.trim() || '';
  const email = document.getElementById('su-email')?.value.trim();
  const pass  = document.getElementById('su-pass')?.value;
  const pass2 = document.getElementById('su-pass2')?.value;
  const btn   = document.getElementById('su-btn');

  // Run all validators
  const n  = validateRegName?.() ?? true;
  const e  = validateRegEmail?.() ?? true;
  const p  = validateRegPass?.() ?? true;
  const p2 = validateRegPass2?.() ?? true;
  if (!n || !e || !p || !p2) return;

  btn.disabled = true; btn.textContent = 'Creating account…';
  try {
    const user = await UserAPI.create({
      name: `${fname} ${lname}`.trim(),
      email: email.toLowerCase(),
      password: pass
    });
    setUser(user);
    showToast(`Welcome to NEXUS, ${fname}!`, 'success');
    goTo('home');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Create Account'; }
  }
}

function doLogout() {
  cartClear();
  clearUser();
  goTo('home');
  showToast('Signed out successfully', 'info');
}

/* ── Helpers ── */
function loading() {
  return `<div class="loading"><div class="spinner"></div>Loading…</div>`;
}
function signWall(action) {
  return `<div class="sign-wall">
    <h2>Sign in to ${action}</h2>
    <p>Create a free account or sign in to continue.</p>
    <div style="display:flex;gap:10px;justify-content:center">
      <button class="btn-primary" onclick="goTo('signin')">Sign In</button>
      <button class="btn-ghost" onclick="goTo('register')">Create Account</button>
    </div>
  </div>`;
}
