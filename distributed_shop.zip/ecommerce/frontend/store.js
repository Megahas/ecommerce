/* store.js — client-side state */

/* ── User session ── */
let currentUser = null;

function setUser(u) {
  currentUser = u;
  try { localStorage.setItem('nexus_user', JSON.stringify(u)); } catch {}
  renderNavbar();
}
function clearUser() {
  currentUser = null;
  try { localStorage.removeItem('nexus_user'); } catch {}
  renderNavbar();
}
function restoreUser() {
  try {
    const s = localStorage.getItem('nexus_user');
    if (s) currentUser = JSON.parse(s);
  } catch {}
}

/* ── Product images (stored in localStorage keyed by product id) ── */
// Format: { [product_id]: dataURL }
function saveProductImage(id, dataURL) {
  try {
    const imgs = JSON.parse(localStorage.getItem('nexus_imgs') || '{}');
    imgs[id] = dataURL;
    localStorage.setItem('nexus_imgs', JSON.stringify(imgs));
  } catch {}
}
function getProductImage(id) {
  try {
    const imgs = JSON.parse(localStorage.getItem('nexus_imgs') || '{}');
    return imgs[id] || null;
  } catch { return null; }
}
// Fallback placeholder images from Unsplash (free, no auth needed)
const FALLBACK_IMGS = {
  1: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80', // headphones
  2: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400&q=80', // keyboard
  3: 'https://images.unsplash.com/photo-1625894749576-4e8e2f68bdb7?w=400&q=80', // usb hub
  4: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&q=80', // laptop stand
};
function productImg(p) {
  return getProductImage(p.id) || FALLBACK_IMGS[p.id] || `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80`;
}

/* ── Cart ── */
let cart = [];

function cartAdd(product, qty = 1) {
  const ex = cart.find(i => i.product.id === product.id);
  if (ex) {
    const nq = ex.qty + qty;
    if (nq > product.stock) { showToast('Not enough stock available', 'error'); return; }
    ex.qty = nq;
  } else {
    if (qty > product.stock) { showToast('Not enough stock available', 'error'); return; }
    cart.push({ product, qty });
  }
  cartSynced();
  showToast(`${product.name} added to cart`, 'success');
}
function cartRemove(id) {
  cart = cart.filter(i => i.product.id !== id);
  cartSynced();
}
function cartSetQty(id, qty) {
  const item = cart.find(i => i.product.id === id);
  if (!item) return;
  if (qty < 1) { cartRemove(id); return; }
  if (qty > item.product.stock) { showToast('Not enough stock', 'error'); return; }
  item.qty = qty;
  cartSynced();
}
function cartClear() { cart = []; cartSynced(); }
function cartTotal() { return cart.reduce((s, i) => s + i.product.price * i.qty, 0); }
function cartCount() { return cart.reduce((s, i) => s + i.qty, 0); }
function cartSynced() {
  updateCartBadge();
  renderCartDrawer();
}

/* ── Products cache ── */
let productsCache = [];
async function loadProducts(force = false) {
  if (productsCache.length && !force) return productsCache;
  productsCache = await ProductAPI.list();
  return productsCache;
}

/* ── Selected payment method ── */
let selectedPayment = 'card'; // 'card' | 'cash' | 'easypaisa' | 'jazzcash'
