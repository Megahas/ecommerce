# Distributed E-Commerce System
### A Microservices Demo for Distributed Computing Course

> **4 services · Docker Compose · FastAPI · SQLite · REST**

---

## Quick Start

```bash
# 1. Clone / unzip the project
cd ecommerce/

# 2. Start all services (builds images on first run)
docker compose up --build

# 3. Open the interactive API docs
# User Service:    http://localhost:8001/docs
# Product Service: http://localhost:8002/docs
# Order Service:   http://localhost:8003/docs
# Payment Service: http://localhost:8004/docs
```

That's it. All four services start, databases are initialised with seed data, and the system is ready.

---

## Architecture Overview

```
                        ┌──────────────────┐
                        │   ORDER SERVICE  │  :8003
                        │   (Orchestrator) │
                        └─────────┬────────┘
              ┌──────────┬────────┴──────────┐
              │          │                    │
              ▼          ▼                    ▼
    ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
    │ USER SERVICE │ │PRODUCT SERVICE│ │PAYMENT SERVICE│
    │    :8001     │ │    :8002     │ │    :8004     │
    └──────────────┘ └──────────────┘ └──────────────┘
    users.db (SQLite) products.db      (stateless)
                      (SQLite)
```

| Service | Port | Database | Responsibility |
|---|---|---|---|
| User Service | 8001 | users.db | Registration & profile |
| Product Service | 8002 | products.db | Catalog & inventory |
| Order Service | 8003 | orders.db | Order orchestration |
| Payment Service | 8004 | (none — stateless) | Payment simulation |

---

## Try It: Place a Complete Order

Run these curl commands in a terminal (or use the `/docs` Swagger UI):

### Step 1 — Check available products
```bash
curl http://localhost:8002/products
```
You'll see 4 seeded products (IDs 1–4).

### Step 2 — Check existing users
```bash
curl http://localhost:8001/users
```
A test user "Alice Smith" (ID: 1) is pre-seeded.

### Step 3 — Place an order
```bash
curl -X POST http://localhost:8003/orders \
  -H "Content-Type: application/json" \
  -d '{"user_id": 1, "product_id": 1, "quantity": 2}'
```

**Success response (~80% of the time):**
```json
{
  "id": 1,
  "user_id": 1,
  "product_id": 1,
  "quantity": 2,
  "total_price": 159.98,
  "payment_status": "SUCCESS",
  "order_status": "CONFIRMED"
}
```

**Failed payment response (~20% of the time):**
```json
{
  "id": 2,
  "payment_status": "FAILED",
  "order_status": "PAYMENT_FAILED"
}
```

### Step 4 — Verify stock was deducted
```bash
curl http://localhost:8002/products/1
# stock should be 48 (was 50, bought 2)
```

### Step 5 — Register a new user
```bash
curl -X POST http://localhost:8001/users \
  -H "Content-Type: application/json" \
  -d '{"name": "Bob Jones", "email": "bob@example.com", "password": "secret"}'
```

---

## Project Structure

```
ecommerce/
├── docker-compose.yml          # Orchestrates all 4 services
├── Dockerfile                  # Shared image definition
├── requirements.txt            # Python dependencies
│
├── user-service/
│   └── main.py                 # FastAPI app
├── product-service/
│   └── main.py
├── order-service/
│   └── main.py                 # Calls all other services
├── payment-service/
│   └── main.py
│
└── docs/
    └── ARCHITECTURE.md         # Full design document (Phase 1)
```

---

## API Reference

### User Service (`:8001`)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/users` | Register a new user |
| GET | `/users/{id}` | Get user by ID |
| GET | `/users` | List all users |

### Product Service (`:8002`)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/products` | Add a product |
| GET | `/products/{id}` | Get product by ID |
| PATCH | `/products/{id}/stock` | Adjust stock |
| GET | `/products` | List all products |

### Order Service (`:8003`)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/orders` | **Place an order** (main flow) |
| GET | `/orders/{id}` | Get order by ID |
| GET | `/orders?user_id=1` | List orders for a user |

### Payment Service (`:8004`)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/pay` | Simulate payment |

---

## Key Design Decisions

### Database per Service
Each service has its own SQLite file stored in a Docker named volume. No service accesses another's database directly. The Order Service stores only `user_id` and `product_id` as references — it calls the respective service's API to resolve full details.

### Why SQLite?
SQLite requires zero configuration and demonstrates the *logical separation* principle without the overhead of running 3 Postgres containers. In production, each service would use the database best suited to its workload.

### Inter-Service Communication
The Order Service uses `httpx` (synchronous mode) to call peers. Docker Compose networking provides DNS resolution: `http://user-service:8000` resolves automatically within the `ecommerce-network` bridge network.

### Payment Simulation
The Payment Service returns `SUCCESS` 80% of the time and `FAILED` 20% of the time using `random.random()`. This lets you demo both the happy path (order confirmed, stock deducted) and the failure path (order recorded as PAYMENT_FAILED, stock unchanged) without any extra setup.

---

## Stopping & Cleanup

```bash
# Stop services (keep data volumes)
docker compose down

# Stop and DELETE all data volumes (fresh start)
docker compose down -v

# View logs for a specific service
docker compose logs -f order-service
```

---

## Extending the System

| Feature | Where to add |
|---|---|
| JWT authentication | User Service — add `/login` endpoint, middleware in Order/Product Service |
| Async order notifications | Add RabbitMQ container; Order Service publishes to `orders` queue |
| Product search | Product Service — add `GET /products?q=keyword` with SQLite FTS |
| Admin dashboard | New `frontend` service in docker-compose, served on port 3000 |
| PostgreSQL migration | Change `DB_PATH` and connection string per service — no other service changes needed |

---

*Distributed Computing Course — Microservices E-Commerce Demo*
