# Architectural Design Document
## Distributed E-Commerce System
**Course:** Distributed Computing  
**CLO Coverage:** CLO-1 (System Design), CLO-2 (Communication & Data Strategy)

---

## 1. Architectural Style: Microservices vs. SOA

### 1.1 Service-Oriented Architecture (SOA)

SOA organises software as a set of **coarse-grained, reusable business services** that communicate over an **Enterprise Service Bus (ESB)**. Key traits:

| Trait | SOA |
|---|---|
| Service granularity | Large, business-domain services |
| Communication | Centralised ESB (e.g., MuleSoft, WSO2) |
| Data sharing | Shared canonical data model |
| Deployment | Typically monolithic WAR/EAR per service |
| Governance | Heavy, centralised |

**Drawbacks for this project:**  
- The ESB becomes a single point of failure.  
- Shared schemas create tight coupling — a change to the User schema breaks every consumer.  
- Heavyweight containers (JBoss, WebSphere) are impractical for a university lab.  
- Difficult to scale individual components; you must scale the whole bus.

---

### 1.2 Microservices Architecture ✅ (Chosen)

Microservices decomposes a system into **small, independently deployable services**, each owning a single bounded context and communicating over lightweight protocols.

| Trait | Microservices |
|---|---|
| Service granularity | Fine-grained, single responsibility |
| Communication | Direct HTTP/REST or gRPC |
| Data storage | Database per service |
| Deployment | Independent containers (Docker) |
| Governance | Decentralised; each team owns their service |

**Why Microservices wins for scalability:**

1. **Independent scaling** — If the Product Service experiences high read load (browsing), you can scale *only* that service to 5 replicas without touching User or Order Service.
2. **Technology heterogeneity** — Each service can use the best database for its workload (PostgreSQL for User, Redis for Session, MongoDB for Product catalogue).
3. **Fault isolation** — A crash in the Payment Service does not bring down Product browsing.
4. **CI/CD velocity** — Teams deploy independently, reducing co-ordination overhead.
5. **Container efficiency** — Each service is a ~50 MB Python image vs. a 500 MB Java EE server.

**REST vs. gRPC:**

| | REST/HTTP | gRPC |
|---|---|---|
| Protocol | HTTP/1.1, JSON | HTTP/2, Protobuf |
| Performance | Moderate | ~5–10× faster serialisation |
| Browser support | Native | Requires grpc-web proxy |
| Learning curve | Low | Medium |
| Best for | Public APIs, rapid prototyping | High-throughput internal services |

**Decision:** **REST** is chosen for this project because it is universally understood, trivially testable with a browser, and perfectly adequate for a university prototype. gRPC is recommended for production internal communication (e.g., Order→Payment) once throughput exceeds ~1,000 req/s.

---

## 2. Communication Protocol

### 2.1 Synchronous vs. Asynchronous

| Dimension | Synchronous (HTTP/REST) | Asynchronous (RabbitMQ/Kafka) |
|---|---|---|
| Coupling | Temporal coupling (caller waits) | Fully decoupled |
| Complexity | Low — standard HTTP | High — broker, queues, consumers |
| Latency | Request-response latency is visible | Background processing; immediate ACK |
| Error handling | Caller handles errors inline | Dead-letter queues, retries |
| Observability | Simple — HTTP status codes | Requires distributed tracing |
| Infra cost | Zero extra components | Broker server required |

### 2.2 Decision: Synchronous (REST) for University Project ✅

**Justification:**

For a *university prototype*, synchronous REST communication is the right choice:

- **No additional infrastructure** — No need to deploy and configure a Kafka cluster or RabbitMQ broker. The four services plus Docker Compose is already substantial complexity.
- **Easier to debug** — You can trace a request end-to-end in a single log stream. Message queues scatter the trace across producers/consumers.
- **Course-appropriate** — Demonstrates the core distributed concept (inter-process communication over a network) without the distraction of message broker administration.
- **Adequate for load** — A university demo will not hit the throughput ceiling of REST (~5,000 req/s on a single FastAPI instance).

**Where async would be justified in production:**

- Order confirmation emails → fire-and-forget to an email queue.
- Inventory restock alerts → event-driven from Product Service.
- Analytics pipeline → stream all order events to Kafka for aggregation.

The architecture is designed so that adding a message queue later requires only changing the *Order Service* without touching User, Product, or Payment services — this is the benefit of loose coupling.

---

## 3. Database Strategy: Database per Service

### 3.1 Pattern Definition

The **Database per Service** pattern mandates that each microservice has **exclusive ownership** of its data store. No other service may access a service's database directly — data is only accessible through the service's published API.

```
┌─────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│   User Service  │    │ Product Service  │    │  Order Service   │
│   ┌──────────┐  │    │  ┌──────────┐   │    │  ┌──────────┐   │
│   │ users.db │  │    │  │products.db│   │    │  │ orders.db│   │
│   └──────────┘  │    │  └──────────┘   │    │  └──────────┘   │
└─────────────────┘    └──────────────────┘    └──────────────────┘
       ↑ API only              ↑ API only              ↑ API only
```

### 3.2 How it Ensures Loose Coupling

1. **Schema autonomy** — The User team can rename columns, split tables, or migrate from SQLite to PostgreSQL without breaking any other service. No shared ORM models exist.
2. **Independent scaling** — Product Service can use a read-optimised database (e.g., Elasticsearch for full-text search) while Order Service keeps a transactional RDBMS. They evolve independently.
3. **Fault isolation** — A corrupt products.db does not prevent users from logging in or orders from being retrieved.
4. **Security boundary** — Database credentials are scoped per service. A compromised Order Service cannot directly query user passwords.

### 3.3 Trade-offs (CAP Theorem implications)

The main challenge is **cross-service joins**. In a monolith, you join Users and Orders in one SQL query. In microservices, the Order Service stores only `user_id` (a foreign key *by convention*, not by DB constraint) and calls the User Service API when it needs the user's name.

This introduces **eventual consistency** — if the User Service is down, the Order Service can still create orders but cannot display user names until User Service recovers. This is a deliberate trade-off: availability over consistency (AP in CAP).

**This project's choice:** SQLite per service, stored in Docker named volumes, providing clear logical and physical separation.

---

## 4. Sustainability Analysis

### 4.1 Environmental Impact of Distributed Architecture

Distributing a system across multiple services has measurable sustainability implications.

#### 4.1.1 Increased Energy Consumption Vectors

| Factor | Impact |
|---|---|
| Network overhead | Each inter-service HTTP call consumes CPU, NIC power, and switch energy. A monolith's equivalent call is a function invocation at near-zero cost. |
| Process overhead | Four separate Python/uvicorn processes consume ~4× the base memory vs. one process. |
| Idle consumption | Docker containers consume CPU cycles even under zero load (heartbeats, health checks). |

**Quantified estimate:** On a laptop, the four services together idle at ~200–300 MB RAM and ~2–5% CPU. A monolith equivalent would use ~80 MB and ~0.5% CPU at idle.

#### 4.1.2 Sustainability Gains from Containerisation

Despite the overhead above, containerisation delivers net sustainability benefits at scale:

1. **Resource bin-packing** — Docker containers share the host kernel. Kubernetes can schedule 50 microservice containers on 3 physical servers instead of 50 VMs on 50 servers, reducing hardware by ~94%.
2. **Right-sizing** — Scale only the hot service. If only Product Service receives load during a sale event, scale it to 10 replicas and keep User Service at 1 replica. A monolith must scale all functionality together, wasting energy on idle code paths.
3. **Faster startup** — Containers start in ~2 seconds vs. 30–60 seconds for a JVM monolith, reducing energy consumed during rolling updates.
4. **Multi-tenancy** — Multiple teams' microservices can share one Kubernetes cluster, maximising physical server utilisation above 70% (vs. ~15% for dedicated VMs).

#### 4.1.3 Recommendations for a Greener Deployment

- **Use ARM-based instances** (AWS Graviton, Apple M-series): ~40% lower energy per compute unit vs. x86.
- **Enable auto-scaling to zero** during off-peak hours (Knative serverless). A university project running overnight consumes wasted energy.
- **Consolidate health checks** — The current 10-second health check interval generates ~1,440 HTTP calls per service per day. Increase to 30 seconds in production.
- **Choose a green cloud region** — GCP `europe-west1` (Belgium) runs on 100% renewable energy. AWS `eu-west-1` (Ireland) operates at 96% carbon-free.
- **Use HTTP/2** (gRPC) for high-frequency service-to-service calls — multiplexed streams reduce TCP handshake overhead by ~60% vs. HTTP/1.1.

#### 4.1.4 Net Verdict

For a **high-traffic production system** (>10,000 users), microservices + containers is *greener* than a monolith because right-sizing and bin-packing outweigh per-call overhead. For a **university demo** with 5 users, a monolith would be more energy-efficient. The architecture choice here is pedagogically motivated, which is entirely valid.

---

## 5. System Interaction Diagram: Place Order Flow

```
User (Browser/curl)
        │
        │  POST /orders  {user_id: 1, product_id: 2, quantity: 1}
        ▼
┌───────────────────────────────────────────────────────────────────┐
│                        ORDER SERVICE :8003                         │
│                                                                    │
│  1. Receive order request                                          │
│       │                                                            │
│       ├──────── GET /users/{user_id} ──────────────────────────►  │
│       │                              ┌──────────────────────────┐ │
│       │                              │    USER SERVICE :8001    │ │
│       │                              │  SELECT * FROM users     │ │
│       │◄─────── {id, name, email} ── │  WHERE id = ?            │ │
│       │                              └──────────────────────────┘ │
│       │                                                            │
│       ├──────── GET /products/{product_id} ──────────────────────►│
│       │                              ┌──────────────────────────┐ │
│       │                              │  PRODUCT SERVICE :8002   │ │
│       │                              │  SELECT * FROM products  │ │
│       │◄─── {id, name, price, stock} │  WHERE id = ?            │ │
│       │                              └──────────────────────────┘ │
│       │                                                            │
│       │  Calculate total = price × quantity                        │
│       │                                                            │
│       ├──────── POST /pay  {user_id, amount} ───────────────────► │
│       │                              ┌──────────────────────────┐ │
│       │                              │  PAYMENT SERVICE :8004   │ │
│       │                              │  random(0,1) < 0.80?     │ │
│       │◄── {status: "SUCCESS|FAILED"}│  → SUCCESS or FAILURE    │ │
│       │                              └──────────────────────────┘ │
│       │                                                            │
│       │  [If SUCCESS]                                              │
│       ├──────── PATCH /products/{id}/stock  {quantity: -1} ──────►│
│       │                              ┌──────────────────────────┐ │
│       │                              │  PRODUCT SERVICE :8002   │ │
│       │                              │  UPDATE products         │ │
│       │◄─── {new_stock: N}           │  SET stock = stock - 1   │ │
│       │                              └──────────────────────────┘ │
│       │                                                            │
│       │  INSERT INTO orders (user_id, product_id, qty,            │
│       │                      total, payment_status, order_status)  │
│       │                                                            │
│       ▼                                                            │
│  Return OrderResponse to caller                                    │
└───────────────────────────────────────────────────────────────────┘
        │
        ▼
User receives: {id, order_status: "CONFIRMED"|"PAYMENT_FAILED", ...}
```

### 5.1 Data Flow Summary

| Step | Source | Destination | Protocol | Purpose |
|---|---|---|---|---|
| 1 | Client | Order Service | HTTP POST | Initiate order |
| 2 | Order Service | User Service | HTTP GET | Validate buyer |
| 3 | Order Service | Product Service | HTTP GET | Check product & stock |
| 4 | Order Service | Payment Service | HTTP POST | Process payment |
| 5 | Order Service | Product Service | HTTP PATCH | Deduct inventory |
| 6 | Order Service | orders.db | SQLite | Persist order record |
| 7 | Order Service | Client | HTTP 201 | Return confirmation |

### 5.2 Failure Scenarios

| Failure | Behaviour |
|---|---|
| User not found | 404 returned immediately; no payment attempted |
| Product out of stock | 409 returned; no payment attempted |
| User Service down | 503 returned; order not created |
| Payment declined | Order created with `order_status=PAYMENT_FAILED`; stock NOT deducted |
| Product Service down during stock deduction | 503 — order is in inconsistent state. In production: compensating transaction (Saga pattern) |

---

*Document version 1.0 — Distributed Computing Course*
